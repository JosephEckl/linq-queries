﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//ID: C2652, Lab1, 9/20/17, CIS200-01, LINQ queries on provided objects
namespace Lab1
{
    public class LinqTest
    {
        public static void Main(string[] args)
        {
            // initialize array of invoices
            Invoice[] invoices = { 
                new Invoice( 83, "Electric sander", 7, 57.98M ), 
                new Invoice( 24, "Power saw", 18, 99.99M ), 
                new Invoice( 7, "Sledge hammer", 11, 21.5M ), 
                new Invoice( 77, "Hammer", 76, 11.99M ), 
                new Invoice( 39, "Lawn mower", 3, 79.5M ), 
                new Invoice( 68, "Screwdriver", 106, 6.99M ), 
                new Invoice( 56, "Jig saw", 21, 11M ), 
                new Invoice( 3, "Wrench", 34, 7.5M ) };

            // Display original array
            Console.WriteLine("Original Invoice Data\n");
            Console.WriteLine("P.Num Part Description     Quant Price"); // Column Headers
            Console.WriteLine("----- -------------------- ----- ------");

            //write out all invoices
            foreach (Invoice inv in invoices)
                Console.WriteLine(inv);

            // column width for formatting
            const int WIDTH = -20;

            //query 1: sort by part description
            var sortByPart =
                from i in invoices
                orderby i.PartDescription
                select i;

            //display query 1
            Console.WriteLine("\nSorted by Part Description\n");
            Console.WriteLine("P.Num Part Description     Quant Price");
            Console.WriteLine("----- -------------------- ----- ------");
            foreach (var element in sortByPart)
            {
                Console.WriteLine(element);
            }

            //query 2: sort by price
            var sortByPrice =
                from i in invoices
                orderby i.Price
                select i;

            //display query 2
            Console.WriteLine("\nSorted by Price\n");
            Console.WriteLine("P.Num Part Description     Quant Price");
            Console.WriteLine("----- -------------------- ----- ------");
            foreach (var element in sortByPrice)
            {
                Console.WriteLine(element);
            }

            //query 3: select part description and quantity and sort by quantity
            var sortByQuantity =
                from i in invoices
                orderby i.Quantity
                select new { i.PartDescription, i.Quantity };

            //display query 3
            Console.WriteLine("\nPart Description and Quantity by Quantity\n");
            Console.WriteLine("Part Description     Quant");
            Console.WriteLine("-------------------- -----");
            foreach (var element in sortByQuantity)
            {
                Console.WriteLine($"{element.PartDescription,WIDTH} {element.Quantity,WIDTH}");
            }

            //query 4: select part description and invoice total and sort by total
            var sortByTotal =
                from i in invoices
                let total = i.Quantity * i.Price
                orderby total
                select new { i.PartDescription, InvoiceTotal = total };

            //display query 4
            Console.WriteLine("\nPart Description and Total by Total\n");
            Console.WriteLine("Part Description     Total");
            Console.WriteLine("-------------------- ---------");
            foreach (var element in sortByTotal)
            {
                Console.WriteLine($"{element.PartDescription,WIDTH} {element.InvoiceTotal,WIDTH:C}");
            }

            //constants for range testing
            const int RANGE_START = 200;
            const int RANGE_END = 500;
            
            //query 5: select totals in a certain range
            var selectTotalsRange =
                from i in sortByTotal
                where (i.InvoiceTotal >= RANGE_START && i.InvoiceTotal <= RANGE_END)
                select new { i.InvoiceTotal };

            //display query 5
            Console.WriteLine("\nInvoiceTotals Within Range\n");
            Console.WriteLine("Total");
            Console.WriteLine("-------");
            foreach (var element in selectTotalsRange)
            {
                Console.WriteLine($"{element.InvoiceTotal,WIDTH:C}");
            }
        }
    }
}